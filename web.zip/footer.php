﻿<?php
	// error_reporting(0);
	// include_once rtrim($_SERVER['DOCUMENT_ROOT'],"/")."/action/log.php";
?>