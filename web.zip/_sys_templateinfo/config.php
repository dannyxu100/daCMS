﻿<?php
	$info = array();  
	 
	//模板名称
	$info['tl_name'] = '凡色100';
	
	//模板编号
	$info['tl_code'] = 'ZHTX-FANCY100';
	
	//模板链接地址
	$info['tl_url'] = 'http://www.sczhtx.com/';
	
	//模板简介
	$info['tl_description'] = '橙色，黑色大气简约。橙色，黑色大气简约。橙色，黑色大气简约。橙色，黑色大气简约。';
	
	//发布日期
	$info['tl_date'] = '2013-7-1';
	 
	//展示图片(多张图片用数组表示，如：$info['images'] = array( "1.jpg", "2.jpg" ); )
	$info['tl_images'] = array( "1.jpg", "2.jpg" );
	
	//设计师
	$info['tl_designer'] = '肖某某';
	
	//前端工程师
	$info['tl_frontend'] = '潇潇';
	
	//软件工程师
	$info['tl_programmer'] = '张小三';
	
?>